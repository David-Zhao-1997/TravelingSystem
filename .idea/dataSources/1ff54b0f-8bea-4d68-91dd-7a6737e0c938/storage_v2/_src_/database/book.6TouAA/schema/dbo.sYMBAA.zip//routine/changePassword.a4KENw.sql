CREATE PROCEDURE dbo.changePassword @phone VARCHAR(20),@newPassword VARCHAR(100) AS
  BEGIN
    UPDATE [user]
    SET psw = @newPassword
    WHERE phone = @phone;
  END
go

