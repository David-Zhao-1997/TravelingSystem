CREATE procedure dbo.verifyCode @phone varchar(20),@psw varchar(100)
as
  begin
    declare @realCode varchar(100) = (select psw from [user] where phone = @phone)
    if(@realCode != @psw)
      begin
        RAISERROR('Incorrect Code', 12, 4);
      end
  end
go

