CREATE PROCEDURE [dbo].[register] @phone    VARCHAR(20), @psw VARCHAR(100)
AS
  BEGIN
    IF exists(SELECT *
              FROM [user]
              WHERE phone = @phone)
      BEGIN
        RAISERROR ('User Already Exist', 12, 3)
      END
    ELSE
      INSERT INTO [user] (phone,psw) VALUES (@phone, @psw)
  END
go

