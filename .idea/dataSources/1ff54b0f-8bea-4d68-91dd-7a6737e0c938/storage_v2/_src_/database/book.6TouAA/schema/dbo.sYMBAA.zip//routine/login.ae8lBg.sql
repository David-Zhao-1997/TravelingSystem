CREATE PROCEDURE dbo.login @phone VARCHAR(20), @psw VARCHAR(100)
AS
  BEGIN
    DECLARE @CorrPassword nvarchar(50)
    IF EXISTS(SELECT [psw] FROM [User] where phone = @phone)
      BEGIN
        SELECT @CorrPassword = [psw] FROM [User] WHERE phone = @phone
        IF(@psw != @CorrPassword)
          BEGIN
            RAISERROR('Incorrect Password', 12, 2);
          END
      END
    ELSE BEGIN
      RAISERROR('User Not Exist', 12, 1);
    END
  END
go

